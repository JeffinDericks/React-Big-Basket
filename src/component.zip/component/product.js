import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { update } from "./slice";
import { FaAngleLeft } from "react-icons/fa6";
import { FaAngleRight } from "react-icons/fa6";
import { FaRupeeSign } from "react-icons/fa";
import { LiaRupeeSignSolid } from "react-icons/lia";
import { MdOutlineSaveAlt } from "react-icons/md";
import { useNavigate } from "react-router-dom";
import { FaShopify } from "react-icons/fa";


const Product = () => {
    const [vegetables, setVegetables] = useState([])
    const select = useSelector((a) => {
        return a.key.keyjson.list
    })
    // console.log(select);

    useEffect(() => {
        const vegproduct = select.filter((a) => {
            return a.product == "vegetables"
        })
        setVegetables(vegproduct)
    }, [])

    const navi = useNavigate();
    const click = (a) => {
        navi(`/productdetails/?id=${a.id}`)
        // console.log(a)
    }

    return (
        <div className="total">
            <div className="container card-section">
                <div className="row">
                    <div className="col-lg-8 col-sm-12 basket">
                        <h1>My Smart Basket</h1>
                    </div>
                    {/* <div className="col-lg-4 view-all">
                        <p>View all</p>
                        <div className="arrow-buttons">
                            <button><FaAngleLeft /></button>
                            <button><FaAngleRight /></button>
                        </div>
                    </div> */}
                </div>
            </div>

            <div className="container cards">
                <div className="row">
                    {vegetables.map((a) => {
                        return (
                            <div className=" col-lg-3 col-md-6 col-sm-12">
                                <div className="mapped">
                                    <img src={a.img} onClick={() => click(a)} />
                                    <h6>FRESHO</h6>
                                    <p>{a.name}</p>
                                    <select>
                                        <option>1kg</option>
                                        <option>500g</option>
                                        <option>2kg</option>
                                        <option>3kg</option>
                                    </select>
                                    <p>$ {a.price}</p>
                                    <div className="shopifyy">
                                        <p><FaShopify /></p>
                                        <p>Get it for ₹19!</p>
                                    </div>
                                    <div className="add-to-cart">
                                        <button className="save"><MdOutlineSaveAlt /></button>
                                        <button className="add">add</button>
                                    </div>
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>

        </div>
    )
}

export default Product