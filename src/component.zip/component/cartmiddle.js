import React from "react";

const Cartmiddle=()=>{
    return(
        <div>
            <img src="https://www.bigbasket.com/media/uploads/banner_images/1904223_gourmet-snacks_460_1st.jpg" style={{width:"100%",marginTop:"20px"}} />
        </div>
    )
}

export default Cartmiddle