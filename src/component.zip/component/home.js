import React from "react";
import Header from "./header";
import Footer from "./footer";
import Product from "./product";
import Carousel from "./carousel";



const Home=()=>{
    return(
        <div>
            <Header />
            <Carousel/>
            <Product/>
            <Footer/>
        </div>
    )
}

export default Home