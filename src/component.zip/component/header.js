import React from "react";
import { FaCompass } from "react-icons/fa";
import { RiShoppingBasketFill } from "react-icons/ri";
import "./mystyle.scss"
import { FaBarsStaggered } from "react-icons/fa6";
import { Link } from "react-router-dom";
import { CiShoppingTag } from "react-icons/ci";
import { useSelector } from "react-redux";

const Header =()=>{
    const select = useSelector((a)=>{
        return a.key.keyjson.count
    })
    console.log(select);
    return(
        <div className="main-header">
            
            <div className="container d-lg-block d-sm-none">
                <div className="row">
                   <div className="col-lg-1 header-img">
                        <img src="https://gumlet-images.assettype.com/afaqs%2F2021-11%2Fc57035f1-ad95-4b5c-881e-086506b1f6db%2Fbb_TATA_Double_line_logo.jpg?format=webp&w=480&dpr=2.6" />
                    </div>
                    <div className="col-lg-8 header-input">
                        <input type="text" placeholder="search for products" />
                    </div>
                    <div className="col-lg-3 header-list">
                        <ul>
                            <li><button><FaCompass /> Select Location</button></li>
                            <li><button className="login">Login/out</button></li>
                            <Link to="/cart">
                                <li><button className="basket">{select>0?select:""}<RiShoppingBasketFill style={{fontSize:"20px"}}  /></button></li>
                            </Link>                            
                        </ul>
                    </div>
                    <div className="col-lg-12 header2">
                        <nav>
                            <button>Shop by category</button>
                            <a href="#">Fruits</a>
                            <a href="#">
                                <Link to="/tea">
                                    Tea
                                </Link>
                            </a>
                            <a href="#">Ghee</a>
                            <a href="#">Rice</a>
                            <a href="#"><CiShoppingTag style={{color:"#f76969"}} /> Offers</a>
                            
                        </nav>
                    </div>
                </div>
            </div>

            <div className="container d-sm-block d-lg-none mob-header">
                <div className="row">
                <div className="col-sm-2 header-img">
                        <img src="https://images.crunchbase.com/image/upload/c_pad,f_auto,q_auto:eco,dpr_1/v1481913057/idpaksg5l65vvdiunlvt.png" />
                    </div>
                    <div className="col-sm-8 header-input">
                        <input type="text" placeholder="search for products" />
                    </div>
                    <div className="col-sm-2 header-bar">
                        <button><FaBarsStaggered /></button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Header