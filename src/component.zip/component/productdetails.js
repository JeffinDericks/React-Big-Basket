import React, { useEffect, useState } from "react";
import { FaShopify } from "react-icons/fa";
import { CiSaveDown2 } from "react-icons/ci";
import { useSearchParams } from "react-router-dom";
import { useSelector } from "react-redux";
import { AiOutlineHome } from "react-icons/ai";
import { LuHeartHandshake } from "react-icons/lu";
import { IoMdTimer } from "react-icons/io";
import { RiEBike2Fill } from "react-icons/ri";
import { MdOutlinePolicy } from "react-icons/md";
import "./mystyle.scss"


const Productdetails=()=>{

    const [productdetails,setProductdetails] = useState([])

    const searchparams=useSearchParams()[0]
    console.log(searchparams.get("ïd"));

    const selector = useSelector((a)=>{
        return a.key.keyjson.list
    })
    console.log(selector);


    useEffect(()=>{
        const product = selector.filter((a)=>{
            return a.id== parseInt(searchparams.get("id"))
        })
        setProductdetails(product)

    },[])

    return(
        <div className="productdetails-page">
            <div className="container">
                <div className="row">
                    <div className="col-lg-12 product-showcase">
                        <p><AiOutlineHome /> Home/Vegetables/<span>need to replace with name</span></p>
                    </div>
                {/* </div>
            </div>
            
            <div className="container">
                <div className="row">                     */}
                    {productdetails.map((a)=>{
                        return (
                    
                        <div className="product-mapping row">
                            <div className="col-lg-4 product-image">
                                {/* <div className="product-image"> */}
                                    <img src={a.img} />
                                {/* </div> */}
                            </div>

                            <div className="col-lg-8 about-product">
                                {/* <div>                         */}
                                    <p className="underline">Fresho</p>
                                    <p className="freshoo">Fresho Cabbage (Loose), 1 pc (approx. 500 g to 800 g)   </p>
                                    <p className="line-through">MRP:₹33</p>
                                    <p className="fresho">Price: ₹20 (₹20 / pc)</p>
                                    <p className="color">You Save:39% OFF</p>
                                    <p className="tax">(inclusive of all taxes)</p>
                                    <div className="shopify">
                                        <p><FaShopify /></p>
                                        <p>Get it for ₹19!</p>
                                    </div>
                                    <div className="product-buttons">
                                        <button className="button1">Add to basket</button>
                                        <button className="button2"><CiSaveDown2 /> Save for later</button>
                                    </div>
                                </div>
                            </div>
                        // </div>
                        )
                })}
                    
                

                </div>
            </div>

            <div className="container whyyy">
                <div className="row">
                    <div className="col-lg-12 why-choose">
                        <p>Why choose Bigbasket?</p>
                    </div>
                    <div className="col-lg-3">
                        <div className="column-shadow">
                            <p><LuHeartHandshake /></p>
                            <p>Quality</p>
                            <p>You can trust</p>
                        </div>
                    </div>
                    <div className="col-lg-3">
                        <div className="column-shadow">
                            <p><IoMdTimer /></p>
                            <p>On time</p>
                            <p>Guarantee</p>
                        </div>
                    </div>
                    <div className="col-lg-3">
                        <div className="column-shadow">
                            <p><RiEBike2Fill /></p>
                            <p>Free</p>
                            <p>Delivery</p>
                        </div>
                    </div>
                    <div className="col-lg-3">
                        <div className="column-shadow">
                            <p><MdOutlinePolicy /></p>
                            <p>Return Policy</p>
                            <p>No Question asked</p>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    )
}

export default Productdetails