import React from "react";
import Header from "./header";

const Buynow=()=>{
    return(
        <div>
            <Header/>
            <div className="container the-end">
                <div className="row">
                    <div className="col-lg-4"></div>
                        <div className="col-lg-4">
                            <div className="purchase-page">
                                <p className="almost">Almost there!</p>
                                <p>help us to reach you</p>
                            </div>
                            <form>
                                <div className="first-last">
                                    <input type="text" placeholder="First name" />
                                    <input type="text" placeholder="Last name" />
                                </div>
                                <div className="phone-number">
                                    <input type="text" placeholder="Phone Number" />
                                </div>
                                <div className="address">
                                    <input type="text" placeholder="Address" />
                                </div>
                                <div>
                                    <input type="number" placeholder="Pin-code" />
                                </div>
                                <div>
                                    <buttom>Purchase</buttom>
                                </div>


                            </form>
                    </div>
                    <div className="col-lg-4"></div>
                </div>
            </div>
        </div>
    )
}

export default Buynow