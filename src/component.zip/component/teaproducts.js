import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { update,update1 } from "./slice";
import { FaAngleLeft } from "react-icons/fa6";
import { FaAngleRight } from "react-icons/fa6";
import { FaRupeeSign } from "react-icons/fa";
import { LiaRupeeSignSolid } from "react-icons/lia";
import { MdOutlineSaveAlt } from "react-icons/md";
import { IoHomeSharp } from "react-icons/io5";
import { FaAngleUp } from "react-icons/fa6";
import { FaStar } from "react-icons/fa";
import { CiStar } from "react-icons/ci";
import { FaRegEye } from "react-icons/fa";
import { FaRegEyeSlash } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

const Teaproduct=()=>{

    const [filter,setFilter] = useState(true)
    // const [adding,setAdding] = useState(false)
    const [tea,setTea] = useState([])

    const select = useSelector((a)=>{
        return a.key.keyjson.list
    })
    console.log(select);

    const dispatch = useDispatch()

    const handleadd=(a)=>{
        dispatch(update(1))
        // setAdding(true)
        console.log(a.id);

        const bool=select.map((e)=>{
                return e.id==a.id?{...e,boolean:true}:e
        })
        console.log(bool);
        dispatch(update1(bool))

    }

    useEffect(()=>{
        const tealist=select.filter((a)=>{
            return a.product == "tea"
        })
        setTea(tealist)
    },[])

    const hidefilter=(e)=>{
        e.preventDefault()
        setFilter(false)
    }

    const showfilter=(e)=>{
        e.preventDefault()
        setFilter(true)
    }

    const navi = useNavigate();
    const click=(a)=>{
        navi(`/productdetails/?id=${a.id}`)
    }

    return(
        <div className="total">


            <div className="container cards">
                <div className="row">
                    <div className="col-sm-12 filter">
                        {filter?<button onClick={hidefilter}><FaRegEyeSlash /> Hide Filter</button>:<button onClick={showfilter}><FaRegEye /> Show filter</button>}
                    </div>
                    {/* <div> */}
                    
                    {
                        filter?
                    
                    <div className="col-lg-3">
                        <div className="rating-section">
                            <p className="p-tag">Refined by</p>
                            <div className="product-rating">
                                <p>Product Rating</p>
                                <p><FaAngleUp /></p>
                            </div>
                            <div className="radio">
                                <input type="radio" />
                                <p><FaStar/> <FaStar /> <FaStar /> <FaStar /> <FaStar /></p>
                            </div>
                            <div className="radio">
                                <input type="radio" />
                                <p><FaStar /> <FaStar /> <FaStar /> <FaStar /> <CiStar /></p>
                            </div>
                            <div className="radio">
                                <input type="radio" />
                                <p><FaStar /> <FaStar /> <FaStar /> <CiStar /> <CiStar /></p>
                            </div>
                            <div className="radio">
                                <input type="radio" />
                                <p><FaStar /> <FaStar /> <CiStar /> <CiStar /> <CiStar /></p>
                            </div>
                            <div className="radio">
                                <input type="radio" />
                                <p><FaStar /> <CiStar /> <CiStar /> <CiStar /> <CiStar /></p>
                            </div>

                            <div className="product-rating">
                                <p>Brands</p>
                                <p><FaAngleUp /></p>
                            </div>
                            <div className="radio">
                                <input type="radio" />
                                <p>Emperia</p>
                            </div>
                            <div className="radio">
                                <input type="radio" />
                                <p>Red Label</p>
                            </div>
                            <div className="radio">
                                <input type="radio" />
                                <p>Taj Mahal</p>
                            </div>
                            {/* <div className="radio">
                                <input type="radio" />
                                <p>3 Roses</p>
                            </div>
                            <div className="radio">
                                <input type="radio" />
                                <p>Lipton Green Tea</p>
                            </div> */}
                        </div>
                    </div>
                    : ""}
                        {tea.map((a)=>{
                            return(
                                
                                <div className=" col-lg-3 col-md-6 col-sm-12">
                                    <div className="mapped">
                                        <img src={a.img} onClick={()=>click(a)} />
                                        <h6>FRESHO</h6>
                                        <p>{a.name}</p>
                                        <select>
                                            <option>1kg</option>
                                            <option>500g</option>
                                            <option>2kg</option>
                                            <option>3kg</option>
                                        </select>
                                        <p>$ {a.price}</p>
                                        <div className="add-to-cart">
                                            <button className="save"><MdOutlineSaveAlt /></button>
                                            {/* {adding? */}
                                            {/* <button className="add" onClick={()=>handleadd(a)}>added</button>: */}
                                            <button className="add" onClick={()=>handleadd(a)}>add</button>
                                            {/* } */}
                                            
                                        </div>
                                    </div>
                                </div>
                            )
                        })}
                    
                    
                    
                    {/* </div> */}

                </div>
                    
                    
            </div>

        </div>
    )
}

export default Teaproduct